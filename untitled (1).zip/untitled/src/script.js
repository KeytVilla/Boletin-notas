// Función para abrir una subventana con los detalles de la nota

function mostrarDetallesNota(nota) {

    // Contenido de la tabla en formato HTML

    const contenidoTabla = `

        <html>

            <head>

                <title>Detalles de la Nota</title>

                <style>

                    body {

                        font-family: Arial, sans-serif;

                        text-align: center;

                        margin: 30px;

                    }

                    table {

                        width: 60%;

                        margin: auto;

                        border-collapse: collapse;

                        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);

                    }

                    th, td {

                        border: 1px solid #ddd;

                        padding: 10px;

                        text-align: center;

                    }

                    th {

                        background-color: #99A5AF;

                        color: white;

                    }

                    tr:nth-child(even) {

                        background-color: #f2f2f2;

                    }

                </style>

            </head>

            <body>

                <h2>Detalles de la Nota</h2>

                <table>

                    <tr>

                        <th>Porcentajes</th>

                        <th>Nota</th>

                    </tr>

                    <tr>

                        <td>60%</td>

                        <td>${(nota * 0.60).toFixed(2)}</td>

                    </tr>

                    <tr>

                        <td>40%</td>

                        <td>${(nota * 0.40).toFixed(2)}</td>

                    </tr>

                    <tr>

                        <td>100%</td>

                        <td>${(nota * 1).toFixed(2)}</td>

                    </tr>

                </table>

            </body>

        </html>

    `;

    // Abrir una nueva ventana emergente y escribir el contenido

    const ventana = window.open('', '_blank', 'width=600,height=400');

    ventana.document.write(contenidoTabla);

    ventana.document.close();

}

// Seleccionar todas las notas y agregar el evento de clic

document.addEventListener('DOMContentLoaded', () => {

    const notas = document.querySelectorAll('.nota');

    notas.forEach((notaElemento) => {

        notaElemento.addEventListener('click', () => {

            const nota = parseFloat(notaElemento.innerText);

            mostrarDetallesNota(nota);

        });

    });

});